
import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CLI
{
    private int year;
    private int month;

    /*
        Command Line Interface for displaying graph of users of website over time
        Arguments:
        [0] API URL
        [1] Start date of filter - Format is "dd-MM-yyyy"
        [2] End date of filter - Format is "dd-MM-yyyy"
     */
    public CLI(String[] args)
    {
        //Connect to API and generate an array of Map Entries from data
        Map.Entry[] entries = generateEntries(connect(args[0]));
        //If start and end date are provided, generate new array from flagged data
        if (args.length == 3)
        {
            String start = args[1];
            String end = args[2];
            boolean flag = false;
            ArrayList<Map.Entry> entryList = new ArrayList<Map.Entry>();
            for (Map.Entry entry : entries)
            {
                String entryDate = (String) entry.getKey();
                if (entryDate.equals(start))
                {
                    flag = true;
                }
                if (flag)
                {
                    entryList.add(entry);
                }
                if (entryDate.equals(end))
                {
                    break;
                }
            }
            Map.Entry[] newEntries = new Map.Entry[entryList.size()];
            if (newEntries.length == 0)
            {
                System.out.println("Invalid date formatting. Correct format is: dd-MM-yyyy");
            }
            for (int i = 0; i < newEntries.length; i++)
            {
                newEntries[i] = entryList.get(i);
            }
            entries = newEntries;
        }

        //Determine how many users each Unicode block should represent
        double max = 0;
        for (Map.Entry entry: entries)
        {
            double users = ((JsonElement) entry.getValue()).getAsInt();
            if (users > max)
            {
                max = users;
            }
        }
        double blockVal = max/100;

        //Display data for each Entry
        for (Map.Entry entry: entries)
        {
            String date = (String) entry.getKey();
            System.out.print(checkDate(date));

            int users = ((JsonElement) entry.getValue()).getAsInt();
            //System.out.println("\t" + getBar(users,blockVal));
            System.out.printf("%-101s %s", "\t" + getBar(users,blockVal), users + "\n");
        }
    }

    //Method for getting a bar from data as a String
    private String getBar(int users, double blockVal)
    {
        String result = "";
        //Array of characters representing the various fractional blocks
        char[] fractionalBlocks = {' ','\u2589','\u258A','\u258B','\u258C','\u258D','\u258E','\u258F'};
        //Array of doubles representing each fractional blocks relative size
        double[] fractions = {0,7.0/8.0, 3.0/4.0, 5.0/8.0, 1.0/2.0, 3.0/8.0, 1.0/4.0, 1.0/8.0};

        //Get each whole block for date
        double blocks = users/blockVal;
        for (int i = 0; i < (int)blocks; i++)
        {
            result += '\u2588';
        }

        //Get correct fractional block
        double remainder = blocks - (int) blocks;
        int closest = 0;
        for (int i = 0; i < 8; i++)
        {
            if (Math.abs(remainder-fractions[i]) < Math.abs(remainder-fractions[closest]))
            {
                closest = i;
            }
            if (fractions[closest] == remainder)
            {
                break;
            }
        }
        if (closest != 0)
        {
            result += fractionalBlocks[closest];
        }
        return result;
    }

    /*
        Method for checking whether month or year has changed.
        If true, return the String for new month or year
        Then (regardless if true), return the day of the month as String
     */
    private String checkDate(String key)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        try
        {
            Date date = format.parse(key);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            int yearNew = calendar.get(Calendar.YEAR);
            int monthNew = calendar.get(Calendar.MONTH);
            String s = "";
            if (monthNew != month || yearNew != year)
            {
                month = monthNew;
                year = yearNew;
                s = "\tYEAR: " + yearNew + " | MONTH: " + String.format("%02d",monthNew+1) +
                        String.format("%-109s %s", "\nDAY:", "USERS:\n");
            }
            return s + String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH)) + " ";
        }
        catch (ParseException e)
        {
            e.printStackTrace();
            return "";
        }
    }

    /*
        Method for connecting to an API
     */
    private JsonObject connect(String url)
    {
        try
        {
            URLConnection connection = new URL(url).openConnection();
            JsonElement json = JsonParser.parseReader(new InputStreamReader((InputStream) connection.getContent()));
            return json.getAsJsonObject();
        }
        catch (IOException e)
        {
            System.out.println("Unable to connect to " + url);
            return new JsonObject();
        }

    }

    /*
        Method to get an array of map entries from the API
     */
    private Map.Entry[] generateEntries(JsonObject jsonObject)
    {
        Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();
        Map.Entry[] entryArray = new Map.Entry[entries.size()];
        entries.toArray(entryArray);
        return entryArray;
    }

    public static void main(String[] args)
    {
        if (!(args.length == 1 || args.length == 3))
        {
            System.out.println("Invalid number of arguments. Correct format:\nurl startDate endDate\n");
            throw new IllegalArgumentException();
        }
        new CLI(args);
    }
}
